// Living Galaxy — how an NPC says a thing, as opposed to what it says.
//
// Until v1.01.91 every line in `data/npc-topics.js` was a template literal with the names
// substituted in. Nine topics, one or two phrasings each, so a pilot listening to the
// trade band for ten minutes heard the same eighteen sentences on a loop. Adding a
// twentieth hand-written line would have bought about forty more seconds before the loop
// closed again — the problem is not the number of lines, it is that a fixed line has no
// axis to vary along.
//
// So this file does not hold sentences. It holds the pieces a sentence is made of, the
// rules for putting them together so the result is grammatical, and a chooser that
// remembers what it has already said. A topic now declares *meaning* — an act, and the
// facts it is about — and the realiser builds an utterance from that. Two ships trading
// the same tip twice produce two different sentences carrying the same information,
// because the wording is generated and the content is not.
//
// ── the three layers ─────────────────────────────────────────────────
//
//   lexicon    words, with the morphology needed to inflect them correctly
//   syntax     frames — ordered slot lists that realise into clauses
//   discourse  register, vocatives, hedges, and the anti-repetition memory
//
// Everything is seeded through `core/rng.js`, so the same world produces the same radio
// chatter and a replay does not diverge on dialogue.

import { stream } from '../core/rng.js';

// ── morphology ───────────────────────────────────────────────────────
//
// Small, honest, and rule-based rather than a table of every form. English regular
// inflection covers almost everything a working ship says on the radio; the irregulars
// that matter here are few enough to list.

const IRREGULAR_PLURAL = {
  cargo: 'cargoes', wharf: 'wharves', shelf: 'shelves', life: 'lives',
  datum: 'data', analysis: 'analyses', crisis: 'crises', person: 'people'
};

/** Regular English pluralisation, with the sibilant and -y rules applied properly. */
export function plural(noun, n = 2) {
  if (n === 1) return noun;
  if (IRREGULAR_PLURAL[noun]) return IRREGULAR_PLURAL[noun];
  if (/(s|x|z|ch|sh)$/.test(noun)) return noun + 'es';
  if (/[^aeiou]y$/.test(noun)) return noun.slice(0, -1) + 'ies';
  if (/[^f]fe$/.test(noun)) return noun.slice(0, -2) + 'ves';
  return noun + 's';
}

const IRREGULAR_VERB = {
  be:    { s: 'is',    past: 'was',    part: 'been',   ing: 'being' },
  have:  { s: 'has',   past: 'had',    part: 'had',    ing: 'having' },
  do:    { s: 'does',  past: 'did',    part: 'done',   ing: 'doing' },
  go:    { s: 'goes',  past: 'went',   part: 'gone',   ing: 'going' },
  run:   { s: 'runs',  past: 'ran',    part: 'run',    ing: 'running' },
  cut:   { s: 'cuts',  past: 'cut',    part: 'cut',    ing: 'cutting' },
  hold:  { s: 'holds', past: 'held',   part: 'held',   ing: 'holding' },
  sit:   { s: 'sits',  past: 'sat',    part: 'sat',    ing: 'sitting' },
  see:   { s: 'sees',  past: 'saw',    part: 'seen',   ing: 'seeing' },
  take:  { s: 'takes', past: 'took',   part: 'taken',  ing: 'taking' },
  get:   { s: 'gets',  past: 'got',    part: 'got',    ing: 'getting' },
  leave: { s: 'leaves',past: 'left',   part: 'left',   ing: 'leaving' },
  lose:  { s: 'loses', past: 'lost',   part: 'lost',   ing: 'losing' },
  come:  { s: 'comes', past: 'came',   part: 'come',   ing: 'coming' },
  send:  { s: 'sends', past: 'sent',   part: 'sent',   ing: 'sending' },
  put:   { s: 'puts',  past: 'put',    part: 'put',    ing: 'putting' },
  pay:   { s: 'pays',  past: 'paid',   part: 'paid',   ing: 'paying' },
  say:   { s: 'says',  past: 'said',   part: 'said',   ing: 'saying' },
  read:  { s: 'reads', past: 'read',   part: 'read',   ing: 'reading' }
};

/** -ing with the consonant-doubling and silent-e rules that make it read as English. */
function gerund(v) {
  if (IRREGULAR_VERB[v]) return IRREGULAR_VERB[v].ing;
  if (/[^aeiou]e$/.test(v)) return v.slice(0, -1) + 'ing';
  if (/^[^aeiou]*[aeiou][^aeiouwxy]$/.test(v)) return v + v.slice(-1) + 'ing';
  return v + 'ing';
}

/**
 * Conjugate.
 *
 * @param {string} v      base form
 * @param {object} agr    { person: 1|2|3, number: 'sg'|'pl', tense: 'pres'|'past', aspect }
 */
export function conjugate(v, agr = {}) {
  const { person = 3, number = 'sg', tense = 'pres', aspect = null } = agr;
  const irr = IRREGULAR_VERB[v];

  if (aspect === 'prog') {
    const be = tense === 'past'
      ? (number === 'sg' && person !== 2 ? 'was' : 'were')
      : (person === 1 && number === 'sg' ? 'am'
        : number === 'pl' || person === 2 ? 'are' : 'is');
    return `${be} ${gerund(v)}`;
  }
  if (aspect === 'perf') {
    const have = tense === 'past' ? 'had'
      : (person === 3 && number === 'sg' ? 'has' : 'have');
    return `${have} ${irr ? irr.part : regularPast(v)}`;
  }
  if (tense === 'past') return irr ? irr.past : regularPast(v);
  if (person === 3 && number === 'sg') return irr ? irr.s : third(v);
  return v;
}

function regularPast(v) {
  if (/e$/.test(v)) return v + 'd';
  if (/[^aeiou]y$/.test(v)) return v.slice(0, -1) + 'ied';
  if (/^[^aeiou]*[aeiou][^aeiouwxy]$/.test(v)) return v + v.slice(-1) + 'ed';
  return v + 'ed';
}

function third(v) {
  if (/(s|x|z|ch|sh|o)$/.test(v)) return v + 'es';
  if (/[^aeiou]y$/.test(v)) return v.slice(0, -1) + 'ies';
  return v + 's';
}

/**
 * a / an, decided on the *sound* rather than the letter.
 *
 * "an hour" and "a union" are the cases a letter test gets wrong, and a radio line that
 * says "a hour" is the kind of thing that reads as broken rather than as terse.
 */
export function article(word) {
  const w = String(word).toLowerCase();
  if (/^(hour|honest|honou?r|heir)/.test(w)) return 'an';
  if (/^(uni|use|user|euro|one|once|ubiq)/.test(w)) return 'a';
  return /^[aeiou]/.test(w) ? 'an' : 'a';
}

/** Determiner + noun, agreeing in number, with the count/mass distinction respected. */
export function np(noun, opts = {}) {
  const { count = 1, det = 'indef', mass = false, adj = null } = opts;
  const head = mass ? noun : plural(noun, count);
  const withAdj = adj ? `${adj} ${head}` : head;
  if (det === 'none') return withAdj;
  if (det === 'def') return `the ${withAdj}`;
  if (det === 'poss') return `${opts.owner || 'my'} ${withAdj}`;
  if (mass) return withAdj;
  if (count > 1) return `${count} ${withAdj}`;
  return `${article(adj || head)} ${withAdj}`;
}

// ── the lexicon ──────────────────────────────────────────────────────
//
// Synonym sets, not single words. Every entry is a set the realiser draws from, which is
// where most of the variety comes from: the same frame with a different verb choice reads
// as a different sentence, and no sentence has to be written twice.

export const LEX = {
  verb: {
    work:    ['work', 'run', 'cut', 'push'],
    move:    ['move', 'shift', 'run', 'shuttle'],
    watch:   ['watch', 'cover', 'hold', 'mind'],
    find:    ['find', 'read', 'pick up', 'catch'],
    give:    ['pass', 'send', 'hand', 'put across'],
    need:    ['need', 'want', 'could use', 'am short'],
    report:  ['read', 'show', 'log', 'mark'],
    leave:   ['leave', 'clear', 'break off', 'stand down']
  },
  noun: {
    ore:     ['ore', 'rock', 'grade', 'cut'],
    face:    ['face', 'seam', 'rock', 'claim'],
    hold:    ['hold', 'bay', 'can'],
    lane:    ['lane', 'corridor', 'run', 'transit'],
    contact: ['contact', 'return', 'signature', 'blip'],
    berth:   ['berth', 'dock', 'ring', 'pad'],
    trouble: ['trouble', 'company', 'a problem', 'attention'],
    work:    ['work', 'a job', 'a run', 'a charter']
  },
  adj: {
    good:    ['good', 'clean', 'fat', 'better than posted'],
    bad:     ['thin', 'poor', 'picked over', 'not worth the burn'],
    quiet:   ['quiet', 'clear', 'dead', 'empty'],
    busy:    ['busy', 'crowded', 'lit up', 'noisy']
  },
  // Discourse markers, split by register. A terse ship does not say "as it happens".
  // A *marker* leads a clause and the clause continues in lower case: "Look, the face reads
  // well." `LEX.ack` below is the other thing — whole sentences, used as the body of an
  // acknowledgement, not as furniture in front of one. Terse register had `Right.` and
  // `Copy.` filed here as markers, which is what produced "Copy. are you holding?" on the
  // radio: a full stop followed by a lowercased word, on every terse line, for four slices.
  marker: {
    terse:   ['', '', '', 'Right,'],
    plain:   ['', 'Look,', 'Listen,', 'For what it is worth,'],
    warm:    ['', 'Hey,', 'Right then,', 'Tell you what,'],
    formal:  ['', 'Be advised,', 'For the record,', 'Note that']
  },
  hedge: {
    terse:   ['', ''],
    plain:   ['', 'I think', 'near enough', 'give or take'],
    warm:    ['', 'if you ask me', 'near enough', 'I reckon'],
    formal:  ['', 'approximately', 'to a first pass', 'nominally']
  },
  ack: {
    terse:   ['Copy.', 'Received.', 'Acknowledged.', 'Logged.'],
    plain:   ['Copy that.', 'Understood.', 'Got it.', 'Noted.'],
    warm:    ['Got you.', 'Fair enough.', 'Right you are.', 'Cheers.'],
    formal:  ['Acknowledged.', 'Received and logged.', 'Understood.', 'Noted for the record.']
  }
};

// ── register ─────────────────────────────────────────────────────────
//
// Which register a ship speaks in is a property of the ship, not of the line, so the same
// character sounds like itself across every topic it ever raises. Derived from role and
// faction rather than stored, so it needs no migration and cannot drift out of step.

export function registerOf(u) {
  if (!u) return 'plain';
  if (u.faction === 'hostile' || u.faction === 'pirate') return 'terse';
  if (u.faction === 'coalition' || u.role === 'fort') return 'formal';
  if (u.role === 'mine' || u.role === 'haul' || u.role === 'build') return 'warm';
  if (u.role === 'combat' || u.role === 'merc') return 'terse';
  return 'plain';
}

// ── choosing without repeating ───────────────────────────────────────
//
// The anti-repetition memory. Keyed by a caller-supplied bucket — usually speaker + topic —
// it refuses to hand back anything used recently in that bucket until the pool would be
// exhausted, at which point it forgets the oldest and carries on. That is what stops the
// radio being a tape loop without needing an enormous corpus: n frames give n distinct
// utterances in a row rather than a coin flip that lands on the same one twice.

const recent = new Map();   // bucket -> array of recently used keys, newest last

export function chooseFrom(list, bucket = 'default', rng = null) {
  if (!Array.isArray(list) || !list.length) return null;
  const seen = recent.get(bucket) || [];
  const fresh = list.filter(x => !seen.includes(keyOf(x)));
  const pool = fresh.length ? fresh : list;
  const draw = rng ? rng.next() : stream('npc-grammar').next();
  const pick = pool[Math.floor(draw * pool.length) % pool.length];

  const next = seen.concat([keyOf(pick)]);
  // Remember at most one short of the pool, so there is always something fresh to pick.
  while (next.length > Math.max(1, list.length - 1)) next.shift();
  recent.set(bucket, next);
  return pick;
}

const keyOf = x => (typeof x === 'string' ? x : (x && (x.id || x.frame)) || JSON.stringify(x));

/** Wipe the repetition memory. Called on a new game; also useful in tests. */
export function resetGrammarMemory() { recent.clear(); }

// ── syntax frames ────────────────────────────────────────────────────
//
// A frame is a function of the semantic record, not a string with holes in it. That is the
// difference that matters: a frame can decide *not* to mention a fact it was not given,
// reorder to put the important thing first, or drop the subject entirely the way real
// radio does — none of which a template can do.
//
// Every frame is tagged with the acts it can express. `realise()` picks among the frames
// that fit the act and the facts actually present.

export const FRAMES = [
  // ── informing ──
  {
    id: 'inform-svo', acts: ['inform', 'tip'],
    needs: ['subject', 'verb'],
    build: (m, g) => `${g.cap(m.subject)} ${conjugate(m.verb, m.agr)}${m.object ? ' ' + m.object : ''}${m.where ? ' ' + m.where : ''}.`
  },
  {
    id: 'inform-fronted', acts: ['inform', 'tip'],
    needs: ['where', 'subject', 'verb'],
    build: (m, g) => `${g.cap(m.where)}, ${m.subject} ${conjugate(m.verb, m.agr)}${m.object ? ' ' + m.object : ''}.`
  },
  {
    id: 'inform-existential', acts: ['inform', 'tip'],
    needs: ['object'],
    build: (m, g) => `There ${m.count > 1 ? 'are' : 'is'} ${m.object}${m.where ? ' ' + m.where : ''}.`
  },
  {
    id: 'inform-verbless', acts: ['inform', 'tip'],
    needs: ['object'],
    // Radio drops the copula constantly. "Two contacts, bearing on the lane."
    build: (m, g) => `${g.cap(m.object)}${m.where ? ', ' + m.where : ''}.`
  },
  {
    id: 'inform-perfect', acts: ['inform'],
    needs: ['subject', 'verb'],
    build: (m, g) => `${g.cap(m.subject)} ${conjugate(m.verb, Object.assign({}, m.agr, { aspect: 'perf' }))}${m.object ? ' ' + m.object : ''}.`
  },
  {
    id: 'inform-progressive', acts: ['inform'],
    needs: ['subject', 'verb'],
    build: (m, g) => `${g.cap(m.subject)} ${conjugate(m.verb, Object.assign({}, m.agr, { aspect: 'prog' }))}${m.object ? ' ' + m.object : ''}${m.where ? ' ' + m.where : ''}.`
  },

  // ── asking ──
  {
    id: 'ask-polar', acts: ['ask'],
    needs: ['subject', 'verb'],
    build: (m, g) => `${m.agr && m.agr.person === 2 ? 'Are you' : 'Is ' + m.subject} ${gerund(m.verb)}${m.object ? ' ' + m.object : ''}?`
  },
  {
    id: 'ask-wh', acts: ['ask'],
    needs: ['object'],
    build: (m, g) => `What have you got ${m.where || 'out there'}?`
  },
  {
    id: 'ask-tag', acts: ['ask'],
    needs: ['object'],
    build: (m, g) => `${g.cap(m.object)}${m.where ? ' ' + m.where : ''} — anything on it?`
  },

  // ── offering and requesting ──
  {
    id: 'offer-direct', acts: ['offer'],
    needs: ['object'],
    build: (m, g) => `I have ${m.object}${m.where ? ' ' + m.where : ''} if you want it.`
  },
  {
    id: 'offer-question', acts: ['offer'],
    needs: ['object'],
    build: (m, g) => `Anyone want ${m.object}? ${m.where ? g.cap(m.where) + '.' : ''}`.trim()
  },
  {
    id: 'request-need', acts: ['request'],
    needs: ['object'],
    build: (m, g) => `I need ${m.object}${m.where ? ' ' + m.where : ''}.`
  },
  {
    id: 'request-polite', acts: ['request'],
    needs: ['object'],
    build: (m, g) => `Any chance of ${m.object}${m.where ? ' ' + m.where : ''}?`
  },

  // ── warning ──
  {
    id: 'warn-imperative', acts: ['warn'],
    needs: ['object'],
    build: (m, g) => `Watch ${m.where || 'yourself'} — ${m.object}.`
  },
  {
    id: 'warn-declarative', acts: ['warn'],
    needs: ['object'],
    build: (m, g) => `${g.cap(m.object)}${m.where ? ' ' + m.where : ''}. Keep your eyes open.`
  },

  // ── acknowledging ──
  {
    id: 'ack-bare', acts: ['ack'],
    needs: [],
    build: (m, g) => g.pick(LEX.ack[m.register] || LEX.ack.plain, 'ack')
  },
  {
    id: 'ack-echo', acts: ['ack'],
    needs: ['object'],
    build: (m, g) => `${g.pick(LEX.ack[m.register] || LEX.ack.plain, 'ack')} ${g.cap(m.object)}.`
  },
  {
    id: 'ack-commit', acts: ['ack'],
    needs: [],
    build: (m, g) => `${g.pick(LEX.ack[m.register] || LEX.ack.plain, 'ack')} I will ${m.verb ? conjugate(m.verb, { person: 1 }) : 'take a look'}.`
  }
];

// ── realisation ──────────────────────────────────────────────────────

const cap = s => (s ? String(s).charAt(0).toUpperCase() + String(s).slice(1) : '');

// "I" is the one English pronoun that is always capitalised wherever it lands.
const fixI = s => String(s).replace(/(^|[\s,;(])i(?=[\s,.;!?)']|$)/g, '$1I');

/**
 * Turn a semantic record into a sentence.
 *
 * @param {object} msg
 *   act       'inform' | 'ask' | 'offer' | 'request' | 'warn' | 'ack'
 *   subject   already-realised NP, or omitted for a subjectless radio fragment
 *   verb      base form
 *   object    already-realised NP
 *   where     a PP or adverbial
 *   agr       agreement for the verb
 *   register  'terse' | 'plain' | 'warm' | 'formal'
 *   count     for existential agreement
 * @param {object} opts { bucket, rng, vocative, marker, hedge }
 */
export function realise(msg, opts = {}) {
  const m = Object.assign({ act: 'inform', register: 'plain', agr: { person: 3, number: 'sg' } }, msg);
  const bucket = opts.bucket || 'default';
  const rng = opts.rng || null;
  const g = {
    cap,
    pick: (list, sub) => chooseFrom(list, `${bucket}:${sub}`, rng) || (list && list[0]) || ''
  };

  const fits = FRAMES.filter(f =>
    f.acts.includes(m.act) && (f.needs || []).every(k => m[k] != null && m[k] !== ''));
  const frame = chooseFrom(fits.length ? fits : FRAMES.filter(f => f.acts.includes('ack')),
                           `${bucket}:frame`, rng);
  if (!frame) return '';

  let body = frame.build(m, g).replace(/\s+/g, ' ').trim();

  // Proper nouns must survive being moved out of sentence-initial position. A discourse
  // marker in front of a clause lowercases the first word — correct for "The face reads
  // well", wrong for "Bulk Hauler 02", and very wrong for "I". Collect the names this
  // record actually mentions and refuse to touch them.
  const propers = [m.subject, m.object, opts.vocative, m.where]
    .filter(x => typeof x === 'string')
    .filter(x => /[A-Z]/.test(x.slice(1)) || /^[A-Z][a-z]+ [A-Z0-9]/.test(x));
  const softLower = t => {
    const first = t.split(' ')[0];
    if (first === 'I') return t;
    if (propers.some(pn => t.startsWith(pn))) return t;
    return t.charAt(0).toLowerCase() + t.slice(1);
  };

  // Discourse furniture, applied after the clause so it never breaks agreement inside it.
  //
  // Two rules learned from reading the comms log rather than the code:
  //
  //   1. An acknowledgement in front of an acknowledgement says nothing twice. "Copy.
  //      acknowledged." and "Right. received." were both real transmissions. A clause that
  //      is *itself* an ack gets no furniture in front of it.
  //   2. A prefix ending in a full stop ends a sentence, so the next word keeps its capital.
  //      Only a clause-leading marker lowercases what follows it.
  //   3. A clause-leading marker takes a declarative. "Look, the face reads well" is speech;
  //      "Note that are you holding?" is not English at all, and formal-register questions
  //      were producing it. Questions get no furniture.
  const reg = m.register;
  const bare = m.act === 'ack' || m.act === 'ask';
  if (opts.marker !== false && !bare) {
    const mk = g.pick(LEX.marker[reg] || LEX.marker.plain, 'marker');
    if (mk) body = /[.!?]$/.test(mk) ? `${mk} ${cap(body)}` : `${mk} ${softLower(body)}`;
  }
  if (opts.hedge) {
    const h = g.pick(LEX.hedge[reg] || LEX.hedge.plain, 'hedge');
    if (h) body = body.replace(/\.$/, `, ${h}.`);
  }
  // Do not address someone twice in one sentence. A topic that already names the listener
  // in the clause ("marking Bulk Hauler 02 on my board") does not also need a vocative.
  if (opts.vocative && !body.includes(opts.vocative)) {
    // Vocative position varies in real speech; front for a call, tail for an aside.
    body = (rng ? rng.next() : stream('npc-grammar').next()) < 0.5
      ? `${opts.vocative}, ${softLower(body)}`
      : body.replace(/\.$/, `, ${opts.vocative}.`);
  }
  return fixI(cap(body));
}

/**
 * Build the object NP for a quantity of something, choosing a synonym and inflecting it.
 * This is where "information constructing" happens: the number is real, and the words
 * around it are chosen fresh each time.
 */
export function quantity(kind, n, opts = {}) {
  const words = LEX.noun[kind] || [kind];
  const word = chooseFrom(words, `${opts.bucket || 'q'}:${kind}`, opts.rng) || kind;
  if (n == null) return np(word, { det: opts.det || 'indef', mass: opts.mass });
  const rounded = Math.round(n);
  if (opts.unit) return `${rounded.toLocaleString('en-US')} ${opts.unit} of ${word}`;
  return `${rounded.toLocaleString('en-US')} ${plural(word, rounded)}`;
}

/** A descriptive NP — "a fat seam", "picked-over rock". */
export function described(kind, quality, opts = {}) {
  const noun = chooseFrom(LEX.noun[kind] || [kind], `${opts.bucket || 'd'}:${kind}`, opts.rng) || kind;
  const adj = chooseFrom(LEX.adj[quality] || [quality], `${opts.bucket || 'd'}:${quality}`, opts.rng) || quality;
  return np(noun, { det: opts.det || 'indef', adj, mass: !!opts.mass });
}

/** A place adverbial, varied. */
export function place(name, opts = {}) {
  const forms = name
    ? [`at ${name}`, `off ${name}`, `out by ${name}`, `${name} side`]
    : ['out here', 'on this leg', 'where I am', 'on the board'];
  return chooseFrom(forms, `${opts.bucket || 'p'}:place`, opts.rng) || forms[0];
}
